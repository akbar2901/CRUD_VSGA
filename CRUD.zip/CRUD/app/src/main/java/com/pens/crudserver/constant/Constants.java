package com.pens.crudserver.constant;
public class Constants {

    public static final String URL_API = "https://vsga.herokuapp.com/";
    public static final String TOKEN = "tokenAKBAR"; // Isi sendiri

}
